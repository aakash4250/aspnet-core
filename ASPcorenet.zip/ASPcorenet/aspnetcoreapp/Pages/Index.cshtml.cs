using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace aspnetcoreapp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            // Initialization or default view
        }

        public void OnPost()
        {
            string errorMessage = "";
            double result = 0;

            try
            {
                if (Request.Form["num1"].Count > 0 && double.TryParse(Request.Form["num1"], out double num1))
                {
                    double.TryParse(Request.Form["num2"], out double num2); // num2 is optional for some operations
                    string operation = Request.Form["operation"];

                    switch (operation.ToUpper())
                    {
                        case "ADD":
                            result = num1 + num2;
                            break;

                        case "SUBTRACT":
                            result = num1 - num2;
                            break;

                        case "MULTIPLY":
                            result = num1 * num2;
                            break;

                        case "DIVIDE":
                            if (num2 != 0)
                            {
                                result = num1 / num2;
                            }
                            else
                            {
                                errorMessage = "Cannot divide by zero!";
                            }
                            break;

                        case "SQUARE ROOT":
                            if (num1 >= 0)
                            {
                                result = Math.Sqrt(num1);
                            }
                            else
                            {
                                errorMessage = "Cannot take square root of a negative number!";
                            }
                            break;

                        case "POWER":
                            result = Math.Pow(num1, num2);
                            break;

                        case "SINE":
                            result = Math.Sin(num1);
                            break;

                        case "COSINE":
                            result = Math.Cos(num1);
                            break;

                        case "TANGENT":
                            result = Math.Tan(num1);
                            break;

                        case "LOGARITHM":
                            if (num1 > 0)
                            {
                                result = Math.Log(num1); // Natural logarithm
                            }
                            else
                            {
                                errorMessage = "Cannot calculate logarithm of a non-positive number!";
                            }
                            break;

                        case "FACTORIAL":
                            if (num1 >= 0 && num1 == (int)num1) // Ensure non-negative integer
                            {
                                result = Factorial((int)num1);
                            }
                            else
                            {
                                errorMessage = "Factorial is only defined for non-negative integers!";
                            }
                            break;

                        default:
                            errorMessage = "Invalid operation.";
                            break;
                    }
                }
                else
                {
                    errorMessage = "Invalid or missing input for num1.";
                }
            }
            catch (Exception ex)
            {
                errorMessage = "An error occurred: " + ex.Message;
            }

            // Store result or error message in ViewData
            ViewData["result"] = string.IsNullOrEmpty(errorMessage)
                ? "Result: " + result.ToString()
                : errorMessage;
        }

        // Helper method to calculate factorial
        private long Factorial(int n)
        {
            if (n == 0 || n == 1)
                return 1;
            return n * Factorial(n - 1);
        }
    }
}
