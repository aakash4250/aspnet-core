﻿let applyExponent exponent value =                              //1. partial Application
    value ** float exponent

let square = applyExponent 2
let cube = applyExponent 3

let squareResults = [square 2.0; square 3.0; square 4.0] 
let cubeResults = [cube 2.0; cube 3.0; cube 4.0]         

printfn "Square results: %A" squareResults
printfn "Cube results: %A" cubeResults


//2)
let rec productOfListTailRec lst acc =
    match lst with
    | [] -> acc
    | head::tail -> productOfListTailRec tail (acc * head)


let productOfList lst = productOfListTailRec lst 1

let result = productOfList [1; 2; 3; 4]
printfn "Product of all elements: %d" result


// 3)Tail recursive function to calculate the product of odd numbers from n down to 1
let rec productOfOddNumbers n acc =
    if n <= 1 then acc  
    else productOfOddNumbers (n - 2) (acc * n)

let productOfOdds n = productOfOddNumbers n 1

let oddProductResult = productOfOdds 11
printfn "Product of odd numbers from 11 to 1: %d" oddProductResult

// 4)A list of strings with extra spaces, type is explicitly set as a list of strings
let names : string list = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]

let trimmedNames = List.map (fun (name: string) -> name.Trim()) names

printfn "Trimmed names: %A" trimmedNames



// 5)Create a sequence of the first 700 positive integers
let sequence = [1..700]

let filteredNumbers = List.filter (fun x -> x % 35 = 0) sequence

let sumOfFiltered = List.fold (+) 0 filteredNumbers

printfn "Sum of multiples of 7 and 5: %d" sumOfFiltered

// 6)A list of strings with a unique name to avoid conflicts
let nameList : string list = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]


let filteredNames = List.filter (fun (name: string) -> name.ToUpper().Contains("I")) nameList

let concatenatedNames = List.fold (+) "" filteredNames

printfn "Concatenated names: %s" concatenatedNames
