let rec productOfOddNumbers n acc =
    if n <= 0 then acc
    else productOfOddNumbers (n - 2) (acc * n)

// Initial call with an odd number
let productOfOdds n = productOfOddNumbers n 1

// Test the function with a sample odd number (11)
let result = productOfOdds 11
printfn "Product of odd numbers from 11 to 1: %d" result
